import cv2
import numpy as np

image = cv2.imread('red_circle.png')  # Load the saved image

if image is None:
    print("Failed to load image. Check if it exists at /tmp/captured_image.png")
else:
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    
    # Define red color range
    lower_red1 = np.array([0, 50, 50])
    upper_red1 = np.array([10, 255, 255])
    lower_red2 = np.array([170, 50, 50])
    upper_red2 = np.array([180, 255, 255])

    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
    mask = mask1 + mask2

    # Show the detected red region
    cv2.imshow("Red Mask", mask)
    cv2.imshow("Original", image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()
